public class sumaDescendente {
    /**
     * 
     * @author Darío Quintillán
     */
    public static int SumaDescendente(int numero) {
        int resto = 0;
        int sumaTotal=numero;
        
            for (int j = 1; j < numero; j *= 10) {
                resto = numero % j;
                
                sumaTotal+=resto;
            
        }
        return sumaTotal;
    }

    public static void main(String[] args) {
        System.out.println(SumaDescendente(4578));
        System.out.println(SumaDescendente(5083));
        System.out.println(SumaDescendente(999));
    }

}
