public class MinutosTranscurridos {
    /**
     * 
     * @author Darío Quintillán
     */

    public static int minutosTranscurridos(int horaA, int minutoA, int horaB, int minutoB) {
        if (horaA > 23 || horaB > 23 || minutoA > 59 || minutoB > 59 || horaA < 0 || horaB < 0 || minutoA < 0
                || minutoB < 0) {
            return -1;
        } else {
            int minutosTotalesA = horaA * 60 + minutoA;
            int minutosTotalesB = horaB * 60 + minutoB;
            int diferencia = 0;
            if (minutosTotalesA >= minutosTotalesB) {
                diferencia = minutosTotalesA - minutosTotalesB;
            } else {
                diferencia = minutosTotalesB - minutosTotalesA;
            }
            return diferencia;

        }

    }

    public static void main(String[] args) {
        System.out.println(minutosTranscurridos(13, 20, 10, 10));
        System.out.println(minutosTranscurridos(10, 10, 24, 60));
    }
}
